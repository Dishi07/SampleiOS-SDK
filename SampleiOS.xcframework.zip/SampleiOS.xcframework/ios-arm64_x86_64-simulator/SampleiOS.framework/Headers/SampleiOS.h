//
//  SampleiOS.h
//  SampleiOS
//
//  Created by 石田大智 on 2024/08/25.
//

#import <Foundation/Foundation.h>

//! Project version number for SampleiOS.
FOUNDATION_EXPORT double SampleiOSVersionNumber;

//! Project version string for SampleiOS.
FOUNDATION_EXPORT const unsigned char SampleiOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SampleiOS/PublicHeader.h>


